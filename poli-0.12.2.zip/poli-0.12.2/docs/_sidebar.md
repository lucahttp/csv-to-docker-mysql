- Getting Started

  - [Installation](installation.md)
  - [Quick Start](quick-start.md)
  - [Configuration](configuration.md)
  - [Upgrade](upgrade.md)

- Basic Concepts

  - [Data Source](data-source.md)
  - [Report](report.md)
  - [Report Component](report-component.md)
  - [User Management](user-management.md)

- Development

  - [Build](build.md)

- Release

  - [Change logs](change-logs.md)