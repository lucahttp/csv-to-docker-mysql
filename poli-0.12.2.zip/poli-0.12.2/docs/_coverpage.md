# <h2 style="color: #0065FF;">Poli</h2>

> An easy-to-use SQL reporting application built for SQL lovers

[GitHub](https://github.com/shzlw/poli)
[Get Started](#Poli)

![color](#f6f9fc)