#!/bin/sh
set -e

java -jar poli-0.12.2.jar --spring.config.name=application,poli
